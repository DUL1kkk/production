from django.db import models
from employees.models import Employees
class Salaries(models.Model):
    year = models.PositiveIntegerField('Год')
    month = models.PositiveIntegerField('Месяц')
    employee = models.ForeignKey(Employees,on_delete=models.CASCADE, verbose_name='Сотрудник')
    procurements = models.PositiveIntegerField('Количество закупок')
    productions = models.PositiveIntegerField('Количество производств')
    sales = models.PositiveIntegerField('Количество продаж')
    common = models.PositiveIntegerField('Общее количество участий')
    salary=models.FloatField("Оклад")
    bonus = models.FloatField('Бонус')
    general = models.PositiveIntegerField('К выдаче')
    is_issued = models.BooleanField('Выдано', default=False)

    class Meta:
        db_table = 'Salaries'

    def __str__(self):
        return f'{self.year} {self.month} {self.employee} {self.general} {self.is_issued}'
