from django.db.models import Count

from production.models import Production
from raw_sale.models import RawMaterialPurchase
from product_sale.models import ProductSale
from employees.models import Employees
from budget.models import Budget
from ..models import Salaries
from datetime import datetime
__all__ = [
    'SalaryService'
]
class SalaryService:
    @staticmethod
    def create_salaries(year: int, month: int):
        # Проверяем, существуют ли уже записи о заработной плате для указанного года и месяца
        if Salaries.objects.filter(year=year, month=month).exists():
            return # Если уже существуют, выходим из метода
    
         # Получаем всех сотрудников из базы данных
        employees = Employees.objects.all()
        for employee in employees:
             # Считаем количество операций по закупке сырья для данного сотрудника за указанный период
            procurements: int = RawMaterialPurchase.objects.filter(
                Employee_id=employee,
                Date__year=year,
                Date__month=month,
            ).count()
# Считаем количество произведенной продукции для данного сотрудника за указанный период
            productions: int = Production.objects.filter(
                Employee_id=employee,
                Date__year=year,
                Date__month=month,
            ).count()
        # Считаем количество продаж продукции для данного сотрудника за указанный период
            sales = ProductSale.objects.filter(
                Employee_id=employee,
                Date__year=year,
                Date__month=month,
            ).count()
# Считаем общее количество операций для данного сотрудника за указанный период
            common = procurements + productions + sales
             # Получаем процент бонуса из первой записи в таблице бюджета
            bonus_percent = Budget.objects.first().Bonus
                # Рассчитываем бонус сотрудника на основе общего количества операций, процента бонуса и его зарплаты

            bonus = bonus_percent * common * employee.Salary / 100
             # Рассчитываем общую заработную плату сотрудника, включая бонус
            general = employee.Salary + bonus
              # Создаем запись о заработной плате для данного сотрудника и указанного периода

            Salaries.objects.create(
                year=year,
                month=month,
                employee=employee,
                procurements=procurements,
                productions=productions,
                sales=sales,
                common=common,
                salary=employee.Salary,
                bonus=bonus,
                general=general,
                is_issued=False # Устанавливаем флаг "не выплачено"
            )

    @staticmethod
    def issue_all(salary_list):
        budget = Budget.objects.first()
        for salary in salary_list:
            budget.Budget_Amount -= salary.general
            budget.save()

            salary.is_issued = True
            salary.save()

    @staticmethod
    def is_issued(salary_list) -> bool:
        for salary in salary_list:
            if not salary.is_issued:
                return False

        return True