from django import forms
from .models import Salaries
from datetime import datetime
def _get_month_name(month_number: int) -> str:
    match month_number:
        case 1: return "Январь"
        case 2: return "Февраль"
        case 3: return "Март"
        case 4: return "Апрель"
        case 5: return "Май"
        case 6: return "Июнь"
        case 7: return "Июль"
        case 8: return "Август"
        case 9: return "Сентябрь"
        case 10: return "Октябрь"
        case 11: return "Ноябрь"
        case 12: return "Декабрь"

class SelectYearMonthForm(forms.Form):
    year_choices = [(None, '----------')] + [(i, i) for i in range(2023, 2050)]
    year = forms.ChoiceField(choices=year_choices, label='Year')

    month_choices = [(None, '----------')] + [(i, _get_month_name(i)) for i in range(1, 13)]
    month = forms.ChoiceField(choices=month_choices, label='Month')
class SalaryForm(forms.ModelForm):
    def __init__(self, *args, **kwargs):
        super(SalaryForm, self).__init__(*args, **kwargs)

        self.fields['year'].widget.attrs['readonly'] = True
        self.fields['month'].widget.attrs['readonly'] = True

    class Meta:
        model = Salaries
        fields = ['year', 'month', 'employee', 'general']




from django import forms
from .models import Salaries

class SalaryUpdateForm(forms.ModelForm):
    class Meta:
        model = Salaries
        fields = ['general']
        widgets = {
            'general': forms.NumberInput(attrs={'class': 'form-control'}),
        }
