
from budget.models import Budget
from django.shortcuts import render, redirect, get_object_or_404
from django.views import View
from django.urls import reverse_lazy
from django.contrib import messages
from django.db import connection
from .models import Salaries
from .forms import SelectYearMonthForm, SalaryUpdateForm


from django.db.models import Sum

class SalariesListView(View):
    template_name = 'salary_list.html'

    def get(self, request, *args, **kwargs):
        year = request.session.get('year')
        month = request.session.get('month')

        if year and month:
            with connection.cursor() as cursor:
                cursor.execute('EXEC CreateOrUpdateSalaries @year=%s, @month=%s', [year, month])

        context = self.get_context_data(year=year, month=month)
        return render(request, self.template_name, context)

    def post(self, request, *args, **kwargs):
        year = request.POST.get('year')
        month = request.POST.get('month')

        request.session['year'] = year
        request.session['month'] = month

        with connection.cursor() as cursor:
            cursor.execute('EXEC CreateOrUpdateSalaries @year=%s, @month=%s', [year, month])

        context = self.get_context_data(year=year, month=month)
        return render(request, self.template_name, context)

    def get_context_data(self, **kwargs):
        year = kwargs.get('year')
        month = kwargs.get('month')
        salaries = Salaries.objects.filter(year=year, month=month).select_related('employee')
        total_general = salaries.aggregate(Sum('general'))['general__sum'] or 0
        context = {
            'salaries': salaries,
            'choice_form': SelectYearMonthForm(initial={'year': year, 'month': month}),
            'is_period_selected': bool(year and month),
            'current_budget': Budget.objects.first().Budget_Amount,
            'total_general': total_general,
        }
        return context



class SalaryIssueAll(View):
    def get(self, request, *args, **kwargs):
        year = request.session.get('year')
        month = request.session.get('month')

        try:
            with connection.cursor() as cursor:
                cursor.execute('EXEC IssueSalaries @year=%s, @month=%s', [year, month])
            messages.success(request, 'Зарплата выдана всем сотрудникам.')
        except Exception as e:
            messages.error(request, f'Ошибка при выдаче зарплаты: {e}')

        return redirect('salaries-list')


class SalaryUpdateView(View):
    template_name = 'edit_salary.html'

    def get(self, request, *args, **kwargs):
        pk = kwargs.get('pk')
        salary = get_object_or_404(Salaries, pk=pk)
        form = SalaryUpdateForm(instance=salary)
        return render(request, self.template_name, {'form': form})

    def post(self, request, *args, **kwargs):
        pk = kwargs.get('pk')
        salary = get_object_or_404(Salaries, pk=pk)
        form = SalaryUpdateForm(request.POST, instance=salary)

        if form.is_valid():
            new_general = form.cleaned_data['general']
            try:
                with connection.cursor() as cursor:
                    cursor.execute('EXEC UpdateSalary @id=%s, @general=%s', [pk, new_general])
                # Обновляем объект зарплаты, чтобы отобразить изменения в шаблоне
                salary.general = new_general
                messages.success(request, 'Зарплата успешно обновлена.')
                return redirect('salaries-list')
            except Exception as e:
                messages.error(request, f'Ошибка при обновлении зарплаты: {e}')

        return render(request, self.template_name, {'form': form})
