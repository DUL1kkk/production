from django.urls import path
from . import views

urlpatterns = [
    path('', views.SalariesListView.as_view(), name='salaries-list'),
    path('issue-all/', views.SalaryIssueAll.as_view(), name='issue-all'),
    path('edit-salary/<int:pk>/', views.SalaryUpdateView.as_view(), name='edit-salary'),
]
