from django.shortcuts import render, get_object_or_404, redirect
from .models import ProductSale
from .forms import ProductSaleForm, ProductSaleFormFilter
from django.db.models import Sum
from budget.models import Budget
from finishedproduct.models import Finishs
from django.contrib import messages
from datetime import date

# def sale_list(request):
#     sales = ProductSale.objects.all()
#     return render(request, 'sale_list.html', {'sales': sales})

def sale_list(request):
    if request.method == 'POST':
        form = ProductSaleFormFilter(request.POST)
        if form.is_valid():
            start_date = form.cleaned_data['start_date']
            end_date = form.cleaned_data['end_date']
            sales = ProductSale.objects.filter(Date__range=[start_date, end_date])
            total_amount = sales.aggregate(total_amount=Sum('Amount'))['total_amount'] or 0
    else:
        form = ProductSaleFormFilter()
        sales = ProductSale.objects.all()
        total_amount = sales.aggregate(total_amount=Sum('Amount'))['total_amount'] or 0

    context = {'sales': sales, 'form': form, 'total_amount': total_amount}
    return render(request, 'sale_list.html', context)

def sale_detail(request, pk):
    sale = get_object_or_404(ProductSale, pk=pk)
    return render(request, 'sale_detail.html', {'sale': sale})



def update_finishedproducts_quantity(finished_product_id, clean_amount, quantity):
    finished_product = Finishs.objects.get(id=finished_product_id)
    finished_product.Quantity -= quantity
    finished_product.Amount -= clean_amount
    finished_product.save()

from django.shortcuts import get_object_or_404

from datetime import datetime, date

def sale_create(request):
    if request.method == 'POST':
        form = ProductSaleForm(request.POST)
        if form.is_valid():
            quantity = form.cleaned_data['Quantity']
            finished_product_id = form.cleaned_data['Product_id'].id
            finished_product = Finishs.objects.get(id=finished_product_id)
            # Получение даты из формы
            sale_date = form.cleaned_data['Date'] or date.today()
            if quantity <= finished_product.Quantity:
                sale = form.save(commit=False)
                # Установка введенной даты
                sale.Date = sale_date
                # Получение объекта бюджета по константному ID
                budget = Budget.objects.get(id=1)
                if budget:
                    percent = budget.Percent
                    # Подсчет суммы с учетом процентов
                    finished_product_price = finished_product.Amount / finished_product.Quantity
                    amount = finished_product_price * quantity
                    clean_amount = amount
                    amount = amount + (amount * (percent / 100))
                    # Обновление бюджета и сохранение продажи
                    budget.Budget_Amount += amount
                    budget.save()
                    sale.Amount = amount
                    sale.save()

                    # Обновление готовой продукции
                    update_finishedproducts_quantity(finished_product_id, clean_amount, quantity)
                    return redirect('sale_list')
                else:
                    messages.error(request, 'Бюджет не найден.')
            else:
                messages.error(request, 'Недостаточно количества для проведения операции.')
        else:
            # Если форма невалидна
            messages.error(request, 'Форма содержит ошибки.')
    else:
        # Используйте текущую дату как начальное значение для формы
        form = ProductSaleForm(initial={'Date': date.today()})

    return render(request, 'sale_form.html', {'form': form})
def sale_edit(request, pk):
    sale = get_object_or_404(ProductSale, pk=pk)
    if request.method == 'POST':
        form = ProductSaleForm(request.POST, instance=sale)
        if form.is_valid():
            sale = form.save()
            return redirect('sale_list')
    else:
        form = ProductSaleForm(instance=sale)
    return render(request, 'sale_form.html', {'form': form, 'sale': sale})

def sale_delete(request, pk):
    sale = get_object_or_404(ProductSale, pk=pk)
    sale.delete()
    return redirect('sale_list')
