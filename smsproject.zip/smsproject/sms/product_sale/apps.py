from django.apps import AppConfig


class ProductSaleConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'product_sale'
