from django.shortcuts import render, get_object_or_404, redirect
from .models import Production
from .forms import ProductionForm, ProductionFormFilter
from django.db.models import Sum
from django.db import connection
from django.contrib import messages
from Ingredients.models import Ingredients
from Rawmaterials.models import RawMaterials
from finishedproduct.models import Finishs
from datetime import date

def list(request):
    if request.method == 'POST':
        form = ProductionFormFilter(request.POST)
        if form.is_valid():
            start_date = form.cleaned_data['start_date']
            end_date = form.cleaned_data['end_date']
            sales = Production.objects.filter(Date__range=[start_date, end_date])
            total_amount = sales.aggregate(total_amount=Sum('Quantity'))['total_amount'] or 0
    else:
        form = ProductionFormFilter()
        sales = Production.objects.all()
        context = {'employees': sales, 'form': form}
        return render(request, 'production_list.html', context)
        total_amount = sales.aggregate(total_amount=Sum('Quantity'))['total_amount'] or 0

    context = {'employees': sales, 'form': form, 'total_amount': total_amount}
    return render(request, 'production_list.html', context)


# def list(request):
#     employees = Production.objects.all()
#     return render(request, 'production_list.html', {'employees': employees})

def detail(request, pk):
    employee = get_object_or_404(Production, pk=pk)
    return render(request, 'production_detail.html', {'employee': employee})




 # Импортируем функцию increase_bonus из вашего модуля services


def delete(request, pk):
    with connection.cursor() as cursor:
        try:
            cursor.execute("EXEC DeleteProduction @ProductionID=%s", [pk])
            return redirect('production_list')
        except Exception as e:
            messages.error(request, f'Ошибка удаления записи: {e}')
            return redirect('production_list')

def create(request):
    if request.method == 'POST':
        form = ProductionForm(request.POST)
        if form.is_valid():
            product_id = form.cleaned_data['Product_id'].id
            quantity = form.cleaned_data['Quantity']
            employee_id = form.cleaned_data['Employee_id'].id
            date = form.cleaned_data['Date']
            with connection.cursor() as cursor:
                try:
                    cursor.execute("EXEC CreateProduction @ProductID=%s, @Quantity=%s, @Date=%s, @EmployeeID=%s", [product_id, quantity, date, employee_id])
                    return redirect('production_list')
                except Exception as e:
                    messages.error(request, f'Ошибка создания записи: {e}')
        else:
            messages.error(request, 'Форма содержит ошибки.')
    else:
        form = ProductionForm()
    return render(request, 'production_form.html', {'form': form})

def edit(request, pk):
    employee = get_object_or_404(Production, pk=pk)
    if request.method == 'POST':
        form = ProductionForm(request.POST, instance=employee)
        if form.is_valid():
            product_id = form.cleaned_data['Product_id'].id
            quantity = form.cleaned_data['Quantity']
            with connection.cursor() as cursor:
                try:
                    cursor.execute("EXEC EditProduction @ProductionID=%s, @ProductID=%s, @Quantity=%s", [pk, product_id, quantity])
                    employee = form.save(commit=False)
                    employee.save()
                    return redirect('production_list')
                except Exception as e:
                    messages.error(request, f'Ошибка редактирования записи: {e}')
    else:
        form = ProductionForm(instance=employee)
    return render(request, 'production_edit.html', {'form': form, 'employee': employee})