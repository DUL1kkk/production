from django.apps import AppConfig


class RawSaleConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'raw_sale'
